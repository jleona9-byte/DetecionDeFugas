const express = require('express');
const app = express();
const path = require('path');
const PORT = 3000;

// Servir el archivo index.html cuando alguien entre a la raíz
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`\n🚀 ¡Servidor corriendo con éxito!`);
    console.log(`🖥️  Visualiza la página en: http://localhost:${PORT}\n`);
});
